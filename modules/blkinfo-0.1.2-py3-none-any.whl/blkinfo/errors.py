"""Module with blkinfo exceptions"""

class NoLsblkFound(Exception):
    """lslkb from util-linux package is not available on the system"""
